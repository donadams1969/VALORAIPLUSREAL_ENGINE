#!/usr/bin/env python3
import json, sys, pathlib, re
from packages.security.eip55_check import is_eip55, to_eip55

def load(p): return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
def dump(p, obj): pathlib.Path(p).write_text(json.dumps(obj, indent=2), encoding="utf-8")

def main():
    if len(sys.argv) < 3:
        print("usage: tokenlist_update.py TOKENLIST.json INPUT.json [--force-checksum]")
        sys.exit(2)
    tokenlist_path, input_path = sys.argv[1], sys.argv[2]
    force = "--force-checksum" in sys.argv[3:]
    tl = load(tokenlist_path)
    items = load(input_path)  # array of {symbol, name, chainId, address, decimals}
    if "tokens" not in tl: tl["tokens"] = []
    existing = {t["symbol"].upper(): i for i, t in enumerate(tl["tokens"]) if t.get("symbol")}

    for it in items:
        sym = it["symbol"].upper().strip()
        addr = it["address"]
        if not re.fullmatch(r"0x[a-fA-F0-9]{40}", addr or ""):
            print(f"[FAIL] {sym}: bad address format: {addr}"); sys.exit(1)
        if not is_eip55(addr):
            if force:
                fixed = to_eip55(addr)
                print(f"[FIX]  {sym}: checksummed -> {fixed}")
                it["address"] = fixed
            else:
                print(f"[FAIL] {sym}: not EIP-55 checksummed (use --force-checksum to fix)"); sys.exit(1)
        # upsert
        if sym in existing:
            idx = existing[sym]
            tl["tokens"][idx].update(it)
            print(f"[UPD]  {sym}")
        else:
            tl["tokens"].append(it)
            print(f"[ADD]  {sym}")

    dump(tokenlist_path, tl)
    print("[OK] TOKENLIST updated:", tokenlist_path)

if __name__ == "__main__":
    main()
