# Tokenlist & Links Auto-Commit v1
**Generated (UTC): 2025-09-01T14:48:58Z**

## Update TOKENLIST.json with checksummed addresses
```bash
python3 scripts/tokenlist_update.py TOKENLIST.json scripts/TOKENLIST_UPDATE_EXAMPLE.json --force-checksum
```

## Auto-commit LINKS.json + LINKS.md on Releases
- Enable the provided workflow; on each Release, it writes **links/LINKS.json** and **links/LINKS.md** and commits them back to the repo (needs **contents: write**).

Use this so Jules can `curl` a stable link like:
```
https://raw.githubusercontent.com/<org>/<repo>/<branch>/links/LINKS.json
```
