# Minimal EIP-55 checker and check-summer
import re
try:
    import sha3
    HAVE_SHA3 = True
except Exception:
    HAVE_SHA3 = False

def is_eip55(address: str) -> bool:
    if not re.fullmatch(r"0x[a-fA-F0-9]{40}", address or ""):
        return False
    if not HAVE_SHA3:
        return True  # best-effort if keccak unavailable
    raw = address[2:]
    h = sha3.keccak_256(raw.lower().encode()).hexdigest()
    for i, ch in enumerate(raw):
        if ch.isalpha():
            v = int(h[i], 16)
            if (v >= 8 and ch != ch.upper()) or (v < 8 and ch != ch.lower()):
                return False
    return True

def to_eip55(address: str) -> str:
    if not HAVE_SHA3:
        return address
    raw = address.replace("0x","").lower()
    h = sha3.keccak_256(raw.encode()).hexdigest()
    out = "0x"
    for i, ch in enumerate(raw):
        if ch.isalpha():
            out += ch.upper() if int(h[i], 16) >= 8 else ch.lower()
        else:
            out += ch
    return out
