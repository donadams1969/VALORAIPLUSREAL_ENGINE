
import numpy as np
from .criteria import energy, enstrophy

def finite_difference_time_derivative(values, dt):
    """Centered finite difference derivative for a time series (len T)."""
    values = np.asarray(values)
    dvdt = np.zeros_like(values)
    dvdt[1:-1] = (values[2:] - values[:-2])/(2*dt)
    # one-sided at the ends
    dvdt[0] = (values[1] - values[0])/dt
    dvdt[-1] = (values[-1] - values[-2])/dt
    return dvdt

def energy_balance_report(u_time, nu, Lx, Ly, Lz, f_time=None, dt=1.0):
    """
    Compute discrete energy balance:
    d/dt E(t) + 2 nu * enstrophy(t) = <f,u>
    Returns dict with arrays for E, dE/dt, dissipation, forcing_work, residual.
    """
    T = u_time.shape[0]
    E = np.zeros(T)
    Diss = np.zeros(T)
    Work = np.zeros(T)

    for t in range(T):
        E[t] = energy(u_time[t], Lx, Ly, Lz)
        # enstrophy = 0.5 ||omega||_2^2, dissipation term is 2 nu * enstrophy
        Diss[t] = 2.0 * nu * enstrophy(u_time[t], Lx, Ly, Lz)
        if f_time is not None:
            # inner product <f,u> ~ \int f·u dV
            ft = f_time[t]
            nx, ny, nz, _ = ft.shape[-4:]
            dV = (Lx/nx)*(Ly/ny)*(Lz/nz)
            Work[t] = np.sum(np.sum(ft * u_time[t], axis=-1))*dV
        else:
            Work[t] = 0.0

    dEdt = finite_difference_time_derivative(E, dt)
    residual = dEdt + Diss - Work
    return {
        "E": E, "dEdt": dEdt, "Dissipation": Diss, "ForcingWork": Work,
        "EnergyBalanceResidual": residual
    }
