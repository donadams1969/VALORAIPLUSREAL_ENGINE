
import numpy as np

def wave_numbers(n, L):
    """
    Return 1D wave numbers for FFT on a periodic interval [0, L).
    """
    k = np.fft.fftfreq(n, d=L/n) * 2*np.pi
    return k

def gradient_periodic(u, Lx, Ly, Lz):
    """
    Compute gradient of a vector field u(x) on a periodic 3D box via FFT.
    u: array (..., nx, ny, nz, 3)
    Returns: grad_u with shape (..., nx, ny, nz, 3, 3) where last dims are (component, derivative-dir)
    """
    nx, ny, nz, _ = u.shape[-4:]
    kx = wave_numbers(nx, Lx)
    ky = wave_numbers(ny, Ly)
    kz = wave_numbers(nz, Lz)
    kxg, kyg, kzg = np.meshgrid(kx, ky, kz, indexing='ij')

    i = 1j
    # FFT of each component
    Ux = np.fft.fftn(u[..., 0], axes=(-3,-2,-1))
    Uy = np.fft.fftn(u[..., 1], axes=(-3,-2,-1))
    Uz = np.fft.fftn(u[..., 2], axes=(-3,-2,-1))

    # Derivatives in Fourier space
    dUx_dx = np.fft.ifftn(i*kxg*Ux, axes=(-3,-2,-1)).real
    dUx_dy = np.fft.ifftn(i*kyg*Ux, axes=(-3,-2,-1)).real
    dUx_dz = np.fft.ifftn(i*kzg*Ux, axes=(-3,-2,-1)).real

    dUy_dx = np.fft.ifftn(i*kxg*Uy, axes=(-3,-2,-1)).real
    dUy_dy = np.fft.ifftn(i*kyg*Uy, axes=(-3,-2,-1)).real
    dUy_dz = np.fft.ifftn(i*kzg*Uy, axes=(-3,-2,-1)).real

    dUz_dx = np.fft.ifftn(i*kxg*Uz, axes=(-3,-2,-1)).real
    dUz_dy = np.fft.ifftn(i*kyg*Uz, axes=(-3,-2,-1)).real
    dUz_dz = np.fft.ifftn(i*kzg*Uz, axes=(-3,-2,-1)).real

    # Assemble gradient tensor
    grad = np.stack([
        np.stack([dUx_dx, dUx_dy, dUx_dz], axis=-1),
        np.stack([dUy_dx, dUy_dy, dUy_dz], axis=-1),
        np.stack([dUz_dx, dUz_dy, dUz_dz], axis=-1),
    ], axis=-2)  # (..., 3, 3)

    return grad

def divergence_periodic(u, Lx, Ly, Lz):
    grad = gradient_periodic(u, Lx, Ly, Lz)  # (..., 3, 3)
    # trace over component and derivative dir
    div = grad[..., 0,0] + grad[..., 1,1] + grad[..., 2,2]
    return div

def curl_periodic(u, Lx, Ly, Lz):
    grad = gradient_periodic(u, Lx, Ly, Lz)
    # curl(u) = (dUz/dy - dUy/dz, dUx/dz - dUz/dx, dUy/dx - dUx/dy)
    curl_x = grad[..., 2,1] - grad[..., 1,2]
    curl_y = grad[..., 0,2] - grad[..., 2,0]
    curl_z = grad[..., 1,0] - grad[..., 0,1]
    return np.stack([curl_x, curl_y, curl_z], axis=-1)
