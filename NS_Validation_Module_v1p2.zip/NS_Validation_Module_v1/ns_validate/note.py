
import json, math
from pathlib import Path

TEX_TEMPLATE = r"""
\documentclass[11pt]{article}
\usepackage{amsmath, amssymb, geometry, booktabs}
\geometry{margin=1in}
\title{Validation Note: Incompressible 3D Navier--Stokes Diagnostics (Periodic Box)}
\author{ValorAiMathAVM$^+$ / ValorAiPhysics$^+$}
\date{\today}

\begin{document}
\maketitle

\section*{Scope (Not a Proof)}
This note summarizes reproducible diagnostics of a velocity dataset for the 3D incompressible Navier--Stokes equations on a periodic domain. The computations audit classical, peer-reviewed criteria (energy balance, Beale--Kato--Majda, Prodi--Serrin, divergence-free residuals). No claim of a Clay Millennium proof is made.

\section*{Equations Checked}
\begin{align*}
\frac{d}{dt}E(t) + 2\nu\,\mathcal{E}(t) &= \langle f(t), u(t) \rangle,\\
E(t) &= \tfrac12\int |u|^2, \quad
\mathcal{E}(t) = \tfrac12\int |\omega|^2.\\
\text{BKM:}\quad
\int_0^T \|\omega(\cdot,t)\|_{L^\infty} dt &< \infty \;\Rightarrow\; \text{smooth on }[0,T].\\
\text{Prodi--Serrin:}\quad
u \in L^p(0,T;L^q),\; 2/p+3/q\le 1,\; q>3 &\Rightarrow \text{regular on }(0,T].
\end{align*}

\section*{Summary Table}
\begin{center}
\begin{tabular}{@{}ll@{}}
\toprule
BKM integral $\int_0^T \|\omega\|_\infty dt$ & {BKM_VAL} \\
Prodi--Serrin norm $\|u\|_{L^p_t L^q_x}$ (p={PVAL}, q={QVAL}) & {PS_VAL} \\
Divergence $L^2$ residual (max over time) & {DIV_MAX} \\
Divergence pass (threshold={DIV_TOL}) & {DIV_PASS} \\
Energy-balance residual RMS & {EB_RMS} \\
\bottomrule
\end{tabular}
\end{center}

\section*{Reproducibility}
A JSON report ({REPORT_NAME}) contains time series and parameters. Hashes should be recorded alongside this PDF in a manifest.

\end{document}
"""

def _rms(arr):
    return (sum(x*x for x in arr)/len(arr))**0.5 if arr else float('nan')

def render_note(report_path: str, out_tex: str, p: float=None, q: float=None, div_tol: float=None):
    with open(report_path, "r") as f:
        rep = json.load(f)
    checks = rep["checks"]
    notes = rep.get("notes", {})
    # derive RMS of energy-balance residual
    eb = checks.get("EnergyBalanceResidual", [])
    eb_rms = _rms(eb)
    # divergence info
    div_series = checks.get("divergence_L2_series", [])
    div_max = max(div_series) if div_series else float('nan')
    # defaults from config if not supplied
    cfg = rep.get("config", {})
    crit = cfg.get("criteria", {})
    if p is None:
        p = crit.get("prodi_serrin_p", None)
    if q is None:
        q = crit.get("prodi_serrin_q", None)
    if div_tol is None:
        div_tol = crit.get("divergence_L2_tol", None)

    tex = TEX_TEMPLATE\
        .replace("{BKM_VAL}", f"{checks.get('BKM_integral', float('nan')):.6e}")\
        .replace("{PVAL}", f"{p}")\
        .replace("{QVAL}", f"{q}")\
        .replace("{PS_VAL}", f"{checks.get('ProdiSerrin_norm', float('nan')):.6e}")\
        .replace("{DIV_MAX}", f"{div_max:.6e}")\
        .replace("{DIV_TOL}", f"{div_tol}")\
        .replace("{DIV_PASS}", "Yes" if checks.get("divergence_pass", False) else "No")\
        .replace("{EB_RMS}", f"{eb_rms:.6e}")\
        .replace("{REPORT_NAME}", Path(report_path).name)

    Path(out_tex).write_text(tex)
    return out_tex
