
import argparse
from .attest import write_manifest
def main():
    ap = argparse.ArgumentParser(description="Write SHA-256 manifest for given files.")
    ap.add_argument("files", nargs="+", help="Files to hash.")
    ap.add_argument("--txt", default="MANIFEST_SHA256.txt", help="Output text manifest path.")
    ap.add_argument("--json", default="manifest_sha256.json", help="Output JSON manifest path.")
    args = ap.parse_args()
    write_manifest(args.files, out_txt=args.txt, out_json=args.json)
    print(f"Wrote {args.txt} and {args.json}")
if __name__ == "__main__":
    main()
