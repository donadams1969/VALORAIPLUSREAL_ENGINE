
import os, json, numpy as np

def load_config(path):
    with open(path, 'r') as f:
        return json.load(f)

def load_field_series(data_dir, pattern="u_{:04d}.npy", T=1):
    """Load velocity snapshots u_{t}.npy with shape (nx,ny,nz,3)."""
    series = []
    for t in range(T):
        fn = os.path.join(data_dir, pattern.format(t))
        arr = np.load(fn)
        series.append(arr)
    return np.stack(series, axis=0)

def load_force_series(data_dir, pattern="f_{:04d}.npy", T=1):
    series = []
    for t in range(T):
        fn = os.path.join(data_dir, pattern.format(t))
        if not os.path.exists(fn):
            return None
        arr = np.load(fn)
        series.append(arr)
    return np.stack(series, axis=0)
