
import subprocess, shutil
from pathlib import Path

class OpenSSLNotFound(RuntimeError):
    pass

def _check_openssl():
    if shutil.which("openssl") is None:
        raise OpenSSLNotFound("`openssl` not found on PATH. Install OpenSSL 1.1.1+ or 3.x.")

def genkey_priv_pem(out_priv_pem: str):
    _check_openssl()
    subprocess.run(["openssl","genpkey","-algorithm","Ed25519","-out",out_priv_pem], check=True)
    return out_priv_pem

def pub_from_priv(priv_pem: str, out_pub_pem: str):
    _check_openssl()
    subprocess.run(["openssl","pkey","-in",priv_pem,"-pubout","-out",out_pub_pem], check=True)
    return out_pub_pem

def sign(priv_pem: str, in_path: str, sig_out: str):
    _check_openssl()
    # Ed25519 requires RAW input (no pre-hash) for pkeyutl
    subprocess.run(["openssl","pkeyutl","-sign","-rawin","-inkey",priv_pem,"-in",in_path,"-out",sig_out], check=True)
    return sig_out

def verify(pub_pem: str, in_path: str, sig_path: str) -> bool:
    _check_openssl()
    # use -pubin and -inkey with public key PEM
    res = subprocess.run(["openssl","pkeyutl","-verify","-rawin","-pubin","-inkey",pub_pem,"-in",in_path,"-sigfile",sig_path])
    return res.returncode == 0
