
import hashlib, json, os, time
from pathlib import Path

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def write_manifest(paths, out_txt="MANIFEST_SHA256.txt", out_json="manifest_sha256.json"):
    """
    Given a list of file paths, write a text and JSON manifest with SHA-256 and file sizes.
    """
    records = []
    for p in paths:
        p = Path(p)
        records.append({
            "file": str(p),
            "size_bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
    ts = int(time.time())
    manifest = {"timestamp_unix": ts, "files": records}
    # Text format
    with open(out_txt, "w") as ft:
        for r in records:
            ft.write(f"{r['sha256']}  {r['file']}\n")
    # JSON format
    with open(out_json, "w") as fj:
        json.dump(manifest, fj, indent=2)
    return manifest
