
import numpy as np
from .spectral import divergence_periodic, curl_periodic, gradient_periodic

def l2_norm(u, Lx, Ly, Lz):
    """Compute L2 norm of vector field on periodic box via discrete sum."""
    nx, ny, nz, _ = u.shape[-4:]
    dV = (Lx/nx)*(Ly/ny)*(Lz/nz)
    return np.sqrt(np.sum(np.sum(u**2, axis=-1))*dV)

def energy(u, Lx, Ly, Lz):
    """Kinetic energy = 0.5 * ||u||_2^2"""
    return 0.5 * l2_norm(u, Lx, Ly, Lz)**2

def enstrophy(u, Lx, Ly, Lz):
    """Enstrophy = 0.5 * ||omega||_2^2"""
    omega = curl_periodic(u, Lx, Ly, Lz)
    nx, ny, nz, _ = u.shape[-4:]
    dV = (Lx/nx)*(Ly/ny)*(Lz/nz)
    return 0.5 * np.sum(np.sum(omega**2, axis=-1))*dV

def sup_norm_vorticity(u, Lx, Ly, Lz):
    omega = curl_periodic(u, Lx, Ly, Lz)
    return np.max(np.sqrt(np.sum(omega**2, axis=-1)))

def divergence_residual(u, Lx, Ly, Lz):
    """Return L2 norm of divergence (should be ~0 for incompressible flows)."""
    div = divergence_periodic(u, Lx, Ly, Lz)
    nx, ny, nz, _ = u.shape[-4:]
    dV = (Lx/nx)*(Ly/ny)*(Lz/nz)
    return np.sqrt(np.sum(div**2)*dV)

def prodi_serrin_norm(u_time, p, q, Lx, Ly, Lz, dt):
    """
    Approximate mixed norm ||u||_{L^p_t L^q_x} over a time series u_time[t, x,y,z,3].
    q in (3, inf], p >= 2 with 2/p + 3/q <= 1 ensures regularity for Leray-Hopf solutions.
    """
    nx, ny, nz, _ = u_time.shape[-4:]
    dV = (Lx/nx)*(Ly/ny)*(Lz/nz)
    # spatial L^q at each time
    if np.isinf(q):
        # essential sup over space of |u|
        spatial = np.max(np.sqrt(np.sum(u_time**2, axis=-1)), axis=(-4,-3,-2))
    else:
        spatial = (np.sum((np.sqrt(np.sum(u_time**2, axis=-1)))**q, axis=(-4,-3,-2))*dV)**(1.0/q)
    # temporal L^p
    if np.isinf(p):
        return np.max(spatial)
    return (np.sum((spatial**p))*dt)**(1.0/p)

def bkm_integral(omega_sup_t, dt):
    """
    Approximate Beale–Kato–Majda integral \int_0^T ||omega||_inf dt
    given a time series of sup norms and time step dt.
    """
    return np.sum(omega_sup_t)*dt
