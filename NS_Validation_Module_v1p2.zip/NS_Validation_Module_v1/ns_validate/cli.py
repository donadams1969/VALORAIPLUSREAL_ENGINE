
import argparse, json, numpy as np
from .io import load_config, load_field_series, load_force_series
from .criteria import bkm_integral, sup_norm_vorticity, divergence_residual, prodi_serrin_norm
from .energy_checks import energy_balance_report

def main():
    p = argparse.ArgumentParser(description="NS Validation Module — BKM, Prodi–Serrin, energy & incompressibility checks.")
    p.add_argument("--config", required=True, help="Path to JSON config.")
    p.add_argument("--out", default="validation_report.json", help="Where to write results JSON.")
    args = p.parse_args()

    cfg = load_config(args.config)
    Lx, Ly, Lz = cfg["domain"]["Lx"], cfg["domain"]["Ly"], cfg["domain"]["Lz"]
    dt = cfg["time"]["dt"]
    T = cfg["time"]["steps"]
    nu = cfg["fluid"]["nu"]
    data_dir = cfg["data"]["dir"]
    upat = cfg["data"].get("u_pattern", "u_{:04d}.npy")
    fpat = cfg["data"].get("f_pattern", "f_{:04d}.npy")
    ps_p = cfg["criteria"].get("prodi_serrin_p", 4.0)
    ps_q = cfg["criteria"].get("prodi_serrin_q", 12.0)
    div_tol = cfg["criteria"].get("divergence_L2_tol", 1e-8)

    U = load_field_series(data_dir, upat, T)
    F = load_force_series(data_dir, fpat, T)

    # Divergence residual at each step & vorticity sup
    div_L2 = []
    omega_sup = []
    for t in range(T):
        divL2 = divergence_residual(U[t], Lx, Ly, Lz)
        div_L2.append(divL2)
        omega_sup.append(sup_norm_vorticity(U[t], Lx, Ly, Lz))

    omega_sup = np.array(omega_sup)
    bkm = bkm_integral(omega_sup, dt)

    # Prodi–Serrin norm
    ps_norm = prodi_serrin_norm(U, ps_p, ps_q, Lx, Ly, Lz, dt)

    # Energy balance
    eb = energy_balance_report(U, nu, Lx, Ly, Lz, F, dt)

    report = {
        "config": cfg,
        "checks": {
            "divergence_L2_series": div_L2,
            "divergence_pass": all(d <= div_tol for d in div_L2),
            "omega_sup_series": omega_sup.tolist(),
            "BKM_integral": float(bkm),
            "ProdiSerrin_norm": float(ps_norm),
            "Energy": eb["E"].tolist(),
            "dEdt": eb["dEdt"].tolist(),
            "Dissipation": eb["Dissipation"].tolist(),
            "ForcingWork": eb["ForcingWork"].tolist(),
            "EnergyBalanceResidual": eb["EnergyBalanceResidual"].tolist(),
        },
        "notes": {
            "BKM_statement": "If integral_0^T ||omega||_inf dt is finite, smoothness persists on [0,T].",
            "ProdiSerrin_statement": "If u in L^p(0,T; L^q), with 2/p + 3/q <= 1 and q > 3, then weak solutions are regular."
        }
    }

    with open(args.out, "w") as f:
        json.dump(report, f, indent=2)
    print(f"Wrote {args.out}")

if __name__ == "__main__":
    main()
