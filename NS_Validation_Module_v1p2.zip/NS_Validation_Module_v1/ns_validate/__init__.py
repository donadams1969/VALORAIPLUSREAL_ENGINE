"""
Navier–Stokes validation toolkit (diagnostics, not a proof).
"""