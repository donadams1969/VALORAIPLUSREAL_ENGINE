
import argparse, sys
from pathlib import Path
from .ed25519_openssl import genkey_priv_pem, pub_from_priv, sign, verify, OpenSSLNotFound

def main():
    ap = argparse.ArgumentParser(description="Ed25519 keygen/sign/verify via OpenSSL (no Python crypto deps).")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("gen", help="Generate Ed25519 keypair (PEM).")
    sp.add_argument("--outdir", default="keys", help="Directory to write priv.pem and pub.pem")

    sp = sub.add_parser("sign", help="Sign a file with Ed25519.")
    sp.add_argument("--key", required=True, help="Private key PEM (Ed25519)")
    sp.add_argument("--in", dest="infile", required=True, help="Input file to sign (raw)")
    sp.add_argument("--out", dest="sigfile", default="signature.bin", help="Signature output path")

    sp = sub.add_parser("verify", help="Verify an Ed25519 signature.")
    sp.add_argument("--pub", required=True, help="Public key PEM")
    sp.add_argument("--in", dest="infile", required=True, help="Input file that was signed")
    sp.add_argument("--sig", required=True, help="Signature file to verify")

    args = ap.parse_args()
    try:
        if args.cmd == "gen":
            Path(args.outdir).mkdir(parents=True, exist_ok=True)
            priv = str(Path(args.outdir) / "priv_ed25519.pem")
            pub  = str(Path(args.outdir) / "pub_ed25519.pem")
            genkey_priv_pem(priv)
            pub_from_priv(priv, pub)
            print(f"Wrote {priv} and {pub}")
        elif args.cmd == "sign":
            sign(args.key, args.infile, args.sigfile)
            print(f"Wrote signature: {args.sigfile}")
        elif args.cmd == "verify":
            ok = verify(args.pub, args.infile, args.sig)
            print("OK: signature VALID" if ok else "FAIL: signature INVALID")
            sys.exit(0 if ok else 1)
    except OpenSSLNotFound as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(127)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
