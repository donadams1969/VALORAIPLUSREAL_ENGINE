
import argparse
from .note import render_note
def main():
    ap = argparse.ArgumentParser(description="Render LaTeX note from a validation_report.json")
    ap.add_argument("--report", required=True, help="Path to validation_report.json")
    ap.add_argument("--out", default="NS_Validation_Note.tex", help="Output .tex file")
    ap.add_argument("--p", type=float, default=None, help="Prodi–Serrin p (optional override)")
    ap.add_argument("--q", type=float, default=None, help="Prodi–Serrin q (optional override)")
    ap.add_argument("--divtol", type=float, default=None, help="Divergence L2 tolerance (optional override)")
    args = ap.parse_args()
    render_note(args.report, args.out, p=args.p, q=args.q, div_tol=args.divtol)
    print(f"Wrote {args.out}")
if __name__ == "__main__":
    main()
