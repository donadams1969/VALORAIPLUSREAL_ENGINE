
# What this module **does** (rigorously) — and what it **does not** claim

**We do not claim a proof of global regularity for 3D Navier–Stokes.**
This module provides a *verifiable, peer-review-friendly* pipeline to check **established regularity criteria and balance laws** on numerical datasets, so that independent teams can reproduce diagnostics and falsify spurious claims.

## Tangible equations checked

1. **Energy balance (periodic box):**
d/dt E(t) + 2ν · Enstrophy(t) = ⟨f(t), u(t)⟩,
with E = 1/2 ∫ |u|^2, Enstrophy = 1/2 ∫ |ω|^2.

2. **Beale–Kato–Majda (BKM) criterion (3D Euler/NS):**
If ∫_0^T ||ω(·,t)||_∞ dt < ∞, then the solution remains smooth on [0,T].

3. **Prodi–Serrin regularity:**
If u ∈ L^p(0,T; L^q(ℝ^3)) with 2/p + 3/q ≤ 1 and q>3, then a Leray–Hopf solution is smooth on (0,T].

4. **Incompressibility check:** ∇·u ≈ 0 in L^2.

These are classical, peer-reviewed facts. This module **audits** datasets against them.

## ValorAiMathAVM+ / ValorAiPhysics+ framing
- **ValorAiMathAVM+**: provides attested-state JSON (`validation_report.json`) with reproducible norms/integrals.
- **ValorAiPhysics+**: provides the spectral calculus (FFT) used for invariants and criteria.

## Evidence against regularity in data (red flags)
- Divergence residuals not converging under refinement.
- Energy balance residuals that grow without bound or contradict dissipation.
- Discrete BKM integral diverging with refinement.
- Failure of Prodi–Serrin bounds even as resolution increases.
