
# NS Validation Module v1 (ValorAiMathAVM+ / ValorAiPhysics+)

A **verifiable diagnostics toolkit** for incompressible 3D Navier–Stokes on a periodic box.
It outputs a hashable `validation_report.json` containing:
- BKM integral approximation
- Prodi–Serrin mixed norm
- Energy balance residual
- Divergence-free residual

> ⚠️ Not a proof of the Clay Millennium Problem — a rigorous, auditable *validation* layer.

## Quick start

```
pip install numpy
python -m ns_validate.cli --config examples/config_example.json --out validation_report.json
```

## Inputs
Velocity snapshots `.npy` arrays shaped `(nx, ny, nz, 3)` named `u_0000.npy, u_0001.npy, ...` in a data directory.
Optional forcing `f_0000.npy, ...` matching shape.

## Config example
See `examples/config_example.json` for domain sizes, viscosity `nu`, time step `dt`, number of steps, and criteria parameters.

## Outputs
- `validation_report.json` with all metrics/series.
- Store with your CI hash or blockchain anchor as needed.


## Attestation (SHA-256)

```
python -m ns_validate.attest_cli validation_report.json --txt MANIFEST_SHA256.txt --json manifest_sha256.json
```

## Build LaTeX note (for submission)

```
python -m ns_validate.note_cli --report validation_report.json --out NS_Validation_Note.tex
```

Compile with your LaTeX toolchain (e.g., `pdflatex NS_Validation_Note.tex`).


## Ed25519 (OpenSSL interop, no Python deps)

Generate keys (PEM), sign a file (raw), verify:

```
# 1) generate Ed25519 keypair
python -m ns_validate.ed25519_cli gen --outdir keys

# 2) sign your report (raw data, required by Ed25519 pkeyutl)
python -m ns_validate.ed25519_cli sign --key keys/priv_ed25519.pem --in examples/validation_report.json --out examples/validation_report.sig

# 3) verify
python -m ns_validate.ed25519_cli verify --pub keys/pub_ed25519.pem --in examples/validation_report.json --sig examples/validation_report.sig
```

> Requires `openssl` on PATH (OpenSSL 1.1.1+ or 3.x). For Ed25519, the CLI uses `pkeyutl -rawin` (no pre-hash), matching RFC 8032.
> If OpenSSL is unavailable, stick with SHA-256 attestation (`attest_cli`) or ask us to enable a **pure-Python RFC8032 fallback** (not constant-time) for air-gapped environments.
