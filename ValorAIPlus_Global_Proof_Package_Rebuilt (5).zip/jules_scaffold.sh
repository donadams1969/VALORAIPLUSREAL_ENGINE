#!/usr/bin/env bash
set -e
mkdir -p src tests
: > src/placeholder.txt
: > tests/placeholder.txt
echo 'Scaffold created: src/ and tests/ with placeholders.'
