# Release Notes (Template)

## Overview
- Summary of changes
- Links to proofs, PDFs, and attestation capsule

## Highlights
- Exact Leray–Helmholtz projection proof + FFT realization
- Energy/stability guarantees; ValorAiMathAVM™ Generational Seal

## Artifacts
- PDF: `ValorAIPlus_NavierStokes_Projection_Proof.pdf`
- Capsule: `attest/attestation_capsule.zip`
- Hashes: `SHA256SUMS.txt`

## Verification
```bash
# Verify capsule & hashes
shasum -a 256 -c SHA256SUMS.txt   # or: sha256sum -c SHA256SUMS.txt
```
