<!-- README Badges (replace YOUR-ORG/YOUR-REPO) -->
[![NS Proof CI](https://github.com/YOUR-ORG/YOUR-REPO/actions/workflows/ns_proof_ci.yml/badge.svg)](https://github.com/YOUR-ORG/YOUR-REPO/actions/workflows/ns_proof_ci.yml)
