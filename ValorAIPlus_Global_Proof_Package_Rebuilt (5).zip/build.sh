#!/usr/bin/env bash
set -e
make all
