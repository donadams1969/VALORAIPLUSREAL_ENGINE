# Build Status (Local Snapshot)
- Generated: 2025-09-01T14:52:14.137257Z
- CI badge snippet is in `README_BADGES.md`. Replace `YOUR-ORG/YOUR-REPO` with your GitHub repo path.
