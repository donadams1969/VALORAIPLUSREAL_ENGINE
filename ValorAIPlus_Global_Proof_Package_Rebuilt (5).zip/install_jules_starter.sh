#!/usr/bin/env bash
set -e
cp -R tools/jules_starter/* .
