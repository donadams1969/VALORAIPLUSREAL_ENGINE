#!/usr/bin/env bash
set -euo pipefail
BUNDLE_DIR="${1:-.}"
OUTDIR="${2:-attest}"
mkdir -p "$OUTDIR" "keys"
MANIFEST="$BUNDLE_DIR/MANIFEST_SHA256.txt"
if [ ! -f "$MANIFEST" ]; then echo "MANIFEST not found at $MANIFEST"; exit 2; fi
# generate keys if absent
if [ ! -f "keys/priv_ed25519.pem" ]; then
  openssl genpkey -algorithm Ed25519 -out keys/priv_ed25519.pem
  openssl pkey -in keys/priv_ed25519.pem -pubout -out keys/pub_ed25519.pem
fi
# sign (rawin per RFC 8032)
openssl pkeyutl -sign -rawin -inkey keys/priv_ed25519.pem -in "$MANIFEST" -out "$OUTDIR/manifest.sig"
# build capsule zip
cd "$OUTDIR"
rm -f attestation_capsule.zip
zip -q attestation_capsule.zip ../MANIFEST_SHA256.txt manifest.sig ../keys/pub_ed25519.pem
echo '{ "created":"'"$(date -u +%FT%TZ)"'" }' > ATT_METADATA.json
zip -q -u attestation_capsule.zip ATT_METADATA.json
echo "Created $OUTDIR/attestation_capsule.zip"
