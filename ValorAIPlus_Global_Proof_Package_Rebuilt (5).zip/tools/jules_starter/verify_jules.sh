#!/usr/bin/env bash
set -e
DIR="${1:-.}"
python3 "$DIR/verify_manifest.py" "$DIR"
