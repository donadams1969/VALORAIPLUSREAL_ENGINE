# JULES Starter Kit — Valor AI+® Navier–Stokes Projection

This kit is **Jules-friendly**: it contains non-empty `src/` and `tests/` folders so Jules won't ignore them,
a SHA-256 manifest for audit, and one-command scripts to **verify** and to **sign** the manifest (OpenSSL Ed25519).

## Quick start (3 steps)

1. **Commit scaffold so Jules can proceed**
```bash
git add src/placeholder.txt tests/placeholder.txt
git commit -m "chore(scaffold): add minimal src/ and tests/"
git push
```

2. **Verify files match the manifest**
```bash
# macOS/Linux
bash verify_jules.sh .

# Windows
verify_jules.bat .
```

3. **(Optional) Sign the manifest + emit an attestation capsule**
Requires OpenSSL + Python 3 (no crypto deps).
```bash
# macOS/Linux
bash sign_manifest.sh .

# Windows
sign_manifest.bat .
```

This produces `attest/attestation_capsule.zip` with MANIFEST, signature, public key, and metadata (hashes).

---

## What’s included
- `src/`, `tests/` — placeholders so Jules recognizes directories
- `verify_manifest.py` — portable SHA-256 verifier
- `verify_jules.sh`, `verify_jules.bat` — one-command wrappers that print ✅ / ❌
- `sign_manifest.sh`, `sign_manifest.bat` — **OpenSSL Ed25519** signing (keygen if needed) and capsule builder
- `MANIFEST_SHA256.txt` — audit hashes for all files in this kit
- `README_JULES.md` — this file

© 2025 That’s Edutainment, LLC. Valor AI+®, ValorAiMath+™, ValorAiMathAVM™ — trademarks/registered marks. Patent Pending.
Generated: 2025-09-01
