#!/usr/bin/env python3
import sys, hashlib
from pathlib import Path

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    manifest = base / "MANIFEST_SHA256.txt"
    if not manifest.exists():
        print("ERROR: MANIFEST_SHA256.txt not found"); sys.exit(2)
    entries = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line=line.strip()
        if not line: continue
        parts=line.split()
        if len(parts)<2: continue
        entries.append((parts[0], parts[-1]))
    ok=True
    for exp,name in entries:
        if name=="MANIFEST_SHA256.txt": 
            print(f"[SKIP] {name}"); 
            continue
        p = base / name
        if not p.exists():
            print(f"[MISSING] {name}"); ok=False; continue
        act = sha256(p)
        if act.lower()==exp.lower():
            print(f"[OK] {name}")
        else:
            print(f"[MISMATCH] {name}\n  expected: {exp}\n  actual:   {act}")
            ok=False
    print("All files match manifest. ✅" if ok else "Verification failed. ❌")
    sys.exit(0 if ok else 1)

if __name__=="__main__":
    main()
