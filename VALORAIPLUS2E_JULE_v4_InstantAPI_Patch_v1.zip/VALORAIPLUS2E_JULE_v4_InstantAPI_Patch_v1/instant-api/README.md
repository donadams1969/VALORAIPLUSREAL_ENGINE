# 🌌 VALORAIPLUS2E — Instant API (stitched into JULE v4)
Zero-wait demo (batch & OpenAI-style).

## Run (Python)
```bash
python3 -m venv .venv && source .venv/bin/activate && pip install -r instant-api/requirements.txt
uvicorn instant-api/src.serving.fastapi_server:app --reload --port 9000
```

## Run (Docker)
```bash
bash instant-api/scripts/run_docker.sh
```

## Endpoints
- GET /health
- POST /generate
- POST /batch_generate
- POST /v1/chat/completions
- POST /predict_tabular
