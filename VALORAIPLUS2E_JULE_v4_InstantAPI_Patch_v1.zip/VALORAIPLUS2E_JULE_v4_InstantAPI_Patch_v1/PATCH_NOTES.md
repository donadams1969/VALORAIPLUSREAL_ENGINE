

## 📦 instant-api stitched in
The `instant-api/` module has been added with batch generation, OpenAI-style routes, Docker assets, and a GHCR buildx workflow.
