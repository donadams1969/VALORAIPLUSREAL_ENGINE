# ValorAiMathAVM — NS Research Workbench (rebuild)
Skeleton for LaTeX/Lean + interval numerics.
