#!/usr/bin/env python3
# ns3d_projection_demo.py
# Demonstrates projection (pressure-Poisson equivalence) in a periodic 3D box.
# CPU by default; optional GPU via CuPy with --gpu.

import argparse, json, time, math
from pathlib import Path

import numpy as np

try:
    import cupy as cp  # optional
except Exception:
    cp = None

def get_xp(use_gpu: bool):
    if use_gpu and cp is not None:
        return cp
    return np

def rfftn3(xp, a):  # 3D real FFT
    return xp.fft.rfftn(a, axes=(0,1,2))

def irfftn3(xp, A, shape):
    return xp.fft.irfftn(A, s=shape, axes=(0,1,2))

def make_wave_numbers(xp, nx, ny, nz):
    kx = xp.fft.fftfreq(nx) * nx
    ky = xp.fft.fftfreq(ny) * ny
    kz = xp.fft.rfftfreq(nz) * nz  # real-to-complex last axis
    KX, KY, KZ = xp.meshgrid(kx, ky, kz, indexing='ij')
    K2 = KX*KX + KY*KY + KZ*KZ
    return KX, KY, KZ, K2

def divergence(xp, ux, uy, uz):
    Ux = rfftn3(xp, ux)
    Uy = rfftn3(xp, uy)
    Uz = rfftn3(xp, uz)
    nx, ny, nz = ux.shape
    KX, KY, KZ, _ = make_wave_numbers(xp, nx, ny, nz)
    div_hat = 1j*(KX*Ux + KY*Uy + KZ*Uz)
    div = irfftn3(xp, div_hat, (nx,ny,nz))
    return div

def project(xp, ux, uy, uz, dt):
    # Compute pressure via Poisson: -Δ p = (1/dt) div(ũ).
    nx, ny, nz = ux.shape
    Ux = rfftn3(xp, ux)
    Uy = rfftn3(xp, uy)
    Uz = rfftn3(xp, uz)
    KX, KY, KZ, K2 = make_wave_numbers(xp, nx, ny, nz)

    div_hat = 1j*(KX*Ux + KY*Uy + KZ*Uz)
    with xp.errstate(divide='ignore', invalid='ignore'):
        p_hat = -div_hat/(dt*K2)
        p_hat = xp.where(K2==0, 0.0, p_hat)  # zero-mean pressure

    # gradient of p
    px_hat = 1j*KX*p_hat
    py_hat = 1j*KY*p_hat
    pz_hat = 1j*KZ*p_hat

    # u^{n+1} = ũ - dt ∇p
    ux_new = ux - dt*irfftn3(xp, px_hat, (nx,ny,nz))
    uy_new = uy - dt*irfftn3(xp, py_hat, (nx,ny,nz))
    uz_new = uz - dt*irfftn3(xp, pz_hat, (nx,ny,nz))

    return ux_new, uy_new, uz_new, p_hat

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nx", type=int, default=64)
    ap.add_argument("--ny", type=int, default=64)
    ap.add_argument("--nz", type=int, default=64)
    ap.add_argument("--dt", type=float, default=1e-2)
    ap.add_argument("--visc", type=float, default=1e-2)
    ap.add_argument("--steps", type=int, default=3)
    ap.add_argument("--gpu", action="store_true")
    ap.add_argument("--outdir", default="artifacts")
    args = ap.parse_args()

    xp = get_xp(args.gpu)
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    # Smooth initial condition
    nx, ny, nz = args.nx, args.ny, args.nz
    Lx = Ly = Lz = 2*math.pi
    x = xp.linspace(0, Lx, nx, endpoint=False)
    y = xp.linspace(0, Ly, ny, endpoint=False)
    z = xp.linspace(0, Lz, nz, endpoint=False)
    X,Y,Z = xp.meshgrid(x,y,z, indexing='ij')

    ux = xp.sin(X)*xp.cos(Y)*xp.cos(Z)
    uy = -xp.cos(X)*xp.sin(Y)*xp.cos(Z)
    uz = 0.1*xp.sin(X+Y+Z)

    # Intermediate step: add a bit of diffusion (linear part) for demonstration
    for n in range(args.steps):
        div_before = divergence(xp, ux, uy, uz)
        div_before_norm = float(xp.linalg.norm(div_before)/ (nx*ny*nz))

        ux, uy, uz, p_hat = project(xp, ux, uy, uz, args.dt)

        div_after = divergence(xp, ux, uy, uz)
        div_after_norm = float(xp.linalg.norm(div_after)/ (nx*ny*nz))

        log = {
            "step": n,
            "gpu": bool(args.gpu and xp is not np),
            "nx": nx, "ny": ny, "nz": nz,
            "dt": args.dt, "visc": args.visc,
            "div_before_l2_per_cell": div_before_norm,
            "div_after_l2_per_cell": div_after_norm
        }
        with open(outdir / f"projection_log_step{n:03d}.json", "w", encoding="utf-8") as f:
            json.dump(log, f, indent=2)
        print(log)

    # Save one pressure spectrum snapshot (CPU-friendly)
    if xp is np:
        psnap = {"shape": [int(nx),int(ny),int(nz//2+1)]}
        with open(outdir / "pressure_hat_snapshot.json", "w", encoding="utf-8") as f:
            json.dump(psnap, f, indent=2)
    else:
        # On GPU we avoid big host transfers; record only meta
        with open(outdir / "pressure_hat_snapshot.json", "w", encoding="utf-8") as f:
            json.dump({"note":"GPU run; snapshot omitted to avoid D2H copy."}, f, indent=2)

if __name__ == "__main__":
    main()
