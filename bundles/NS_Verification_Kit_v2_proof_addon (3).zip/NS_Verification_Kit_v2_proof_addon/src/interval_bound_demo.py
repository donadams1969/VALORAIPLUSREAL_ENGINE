#!/usr/bin/env python3
# interval_bound_demo.py
# Small certified checks using mpmath.iv intervals.

from mpmath import iv
import json
from pathlib import Path

def main():
    out = {}
    # Example: certify that the projection operator removes divergence (toy 1D analogue)
    # Here we just demonstrate interval arithmetic on a simple linear transform.
    a = iv.mpf([0.999999, 1.000001])  # interval for a scalar close to 1
    b = iv.mpf([-1e-12, 1e-12])       # tiny divergence residual interval
    proj = a*b - b + b  # contrived identity; result contains 0
    out["interval_demo_contains_zero"] = (proj.a <= 0 <= proj.b)

    # Bound of a simple dissipative step x_{n+1} = x_n - dt*c*x_n with c in [c0,c1]
    dt = iv.mpf([0.0099, 0.0101])
    c  = iv.mpf([0.9, 1.1])
    x0 = iv.mpf([0.99, 1.01])
    x1 = x0 - dt*c*x0
    out["dissipative_step_upper"] = float(x1.b)
    out["dissipative_step_lower"] = float(x1.a)

    Path("artifacts").mkdir(parents=True, exist_ok=True)
    with open("artifacts/interval_checks.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(out)

if __name__ == "__main__":
    main()
