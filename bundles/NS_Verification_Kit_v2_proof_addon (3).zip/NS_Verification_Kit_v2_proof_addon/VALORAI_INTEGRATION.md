# VALORAI_INTEGRATION.md

These are *no-op* integration stubs to plug this kit into ValorAiChip+ workflows:

- `VALORAI-HOOKS/config.json` — ID & run‑metadata.
- `tools/build_manifest.py` — produces MANIFEST_SHA256.txt
- `artifacts/` — JSON logs suitable for signing by your existing Ed25519 routine.

> To sign artifacts with your own keys, point your signer at files in `artifacts/`.
