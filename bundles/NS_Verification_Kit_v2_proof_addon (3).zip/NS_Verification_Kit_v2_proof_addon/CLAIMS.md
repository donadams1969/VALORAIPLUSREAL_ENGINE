# CLAIMS.md — Scope of Results

**We claim:**

1. A rigorous derivation (Fourier/Hodge) that the projection operator \(\mathcal{P} = I - \nabla \Delta^{-1} \nabla\cdot\) enforces discrete incompressibility and is equivalent to solving a pressure Poisson equation in the Chorin/Temam step.
2. Numerical demonstrations (CPU/GPU) show:
   - Post‑projection divergence is at or near machine epsilon for smooth test fields.
   - The recovered pressure field solves the discrete Poisson problem to solver tolerance.
3. Interval‑arithmetic utilities bound numerical roundoff and confirm divergence‑free status within certified intervals for small time steps and moderate grids.

**We do *not* claim:**

- A proof of 3D Navier–Stokes global regularity (existence/smoothness for all time). This remains open.
- Any “quantum override” of proof obligations.

This file is intentionally explicit to prevent over‑claiming.
