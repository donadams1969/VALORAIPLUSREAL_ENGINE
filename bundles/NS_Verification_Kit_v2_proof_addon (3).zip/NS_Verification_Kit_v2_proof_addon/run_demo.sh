#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python src/ns3d_projection_demo.py --nx 64 --ny 64 --nz 64 --steps 3
python src/interval_bound_demo.py
python tools/build_manifest.py
echo 'Done.'
