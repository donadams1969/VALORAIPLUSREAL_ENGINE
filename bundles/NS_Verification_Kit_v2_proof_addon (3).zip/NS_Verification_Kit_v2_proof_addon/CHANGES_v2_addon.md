# CHANGES — v2 Proof Add‑on

- Added `proofs/fft_projection_proof.tex` with step‑by‑step derivation.
- Added `proofs/energy_estimates_semi_discrete.tex` notes.
- New `src/ns3d_projection_demo.py` (CPU/GPU) with signed artifact logs.
- New `src/interval_bound_demo.py` using `mpmath.iv`.
- Added `tools/build_manifest.py` and `tools/hash_util.py`.
- ValorAiChip+ integration stubs in `VALORAI-HOOKS/` and `VALORAI_INTEGRATION.md`.
