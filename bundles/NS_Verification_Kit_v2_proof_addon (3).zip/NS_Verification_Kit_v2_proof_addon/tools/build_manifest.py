#!/usr/bin/env python3
# tools/build_manifest.py
import pathlib, json
from hash_util import sha256_of_file

def main():
    root = pathlib.Path(__file__).resolve().parents[1]
    files = []
    for p in root.rglob("*"):
        if p.is_file():
            if p.name.endswith(".zip"):  # skip generated zip
                continue
            files.append(p.relative_to(root))

    lines = []
    manifest = {}
    for rel in sorted(files):
        path = root / rel
        digest = sha256_of_file(path)
        lines.append(f"{digest}  {rel.as_posix()}")
        manifest[rel.as_posix()] = digest

    (root / "MANIFEST_SHA256.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (root / "artifacts").mkdir(parents=True, exist_ok=True)
    (root / "artifacts" / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Wrote MANIFEST_SHA256.txt with {len(files)} entries.")

if __name__ == "__main__":
    main()
