#!/usr/bin/env python3
# Minimal Ed25519: keygen, sign, verify (uses the 'nacl' library if available; fallback to 'cryptography').
import argparse, sys, base64
from pathlib import Path

# Try libs in order
try:
    from nacl.signing import SigningKey, VerifyKey  # type: ignore
    impl = "pynacl"
except Exception:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
        from cryptography.hazmat.primitives import serialization
        impl = "cryptography"
    except Exception:
        sys.stderr.write("ERROR: install 'pynacl' or 'cryptography' to use ed25519_sign.py\n")
        sys.exit(1)

def keygen(outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    if impl == "pynacl":
        sk = SigningKey.generate()
        pk = sk.verify_key
        (outdir / "private.key").write_bytes(sk.encode())
        (outdir / "public.key").write_bytes(pk.encode())
    else:
        sk = Ed25519PrivateKey.generate()
        pk = sk.public_key()
        (outdir / "private.key").write_bytes(
            sk.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )
        (outdir / "public.key").write_bytes(pk.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ))
    print(f"Generated keys in {outdir} using {impl}")

def sign(priv_path: Path, file_path: Path, out_sig: Path):
    data = file_path.read_bytes()
    sk_bytes = priv_path.read_bytes()
    if impl == "pynacl":
        sk = SigningKey(sk_bytes)
        sig = sk.sign(data).signature
    else:
        sk = Ed25519PrivateKey.from_private_bytes(sk_bytes)
        sig = sk.sign(data)
    out_sig.write_bytes(sig)
    print(f"Signed {file_path} -> {out_sig}")

def verify(pub_path: Path, file_path: Path, sig_path: Path):
    data = file_path.read_bytes()
    sig = sig_path.read_bytes()
    pk_bytes = pub_path.read_bytes()
    if impl == "pynacl":
        pk = VerifyKey(pk_bytes)
        pk.verify(data, sig)
    else:
        pk = Ed25519PublicKey.from_public_bytes(pk_bytes)
        pk.verify(sig, data)
    print("OK: signature is valid.")

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_k = sub.add_parser("keygen"); ap_k.add_argument("--out", required=True)
    ap_s = sub.add_parser("sign"); ap_s.add_argument("--priv", required=True); ap_s.add_argument("--file", required=True); ap_s.add_argument("--out", required=True)
    ap_v = sub.add_parser("verify"); ap_v.add_argument("--pub", required=True); ap_v.add_argument("--file", required=True); ap_v.add_argument("--sig", required=True)

    args = ap.parse_args()
    if args.cmd == "keygen":
        keygen(Path(args.out))
    elif args.cmd == "sign":
        sign(Path(args.priv), Path(args.file), Path(args.out))
    elif args.cmd == "verify":
        verify(Path(args.pub), Path(args.file), Path(args.sig))

if __name__ == "__main__":
    main()
