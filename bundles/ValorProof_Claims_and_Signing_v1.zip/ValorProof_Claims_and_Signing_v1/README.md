# ValorProof — Claims, Research Loop, Legal Comms & Signing Toolkit (v1)

**Goal:** Keep our Navier–Stokes communications *100% truthful*, *verifiable*, and *professionally presentable* while we continue real research. This toolkit integrates your **ValorLoop+** (research loop) and **ValorLegal+** (communications/IP) ideas into concrete checklists, templates, and attestation tools.

> ⚠️ **Reality check (as of 2025‑08‑31):** A complete, peer‑accepted proof of **3D Navier–Stokes global regularity** is *not known*. This toolkit does **not** claim to prove it. It helps us state exactly what *is* verified, structure the research to pursue new results, and package artifacts with cryptographic signatures.

## What’s inside
- `CLAIM_POLICY.md` — exact language we *can* claim vs. must *not* claim.
- `PROOF_GATE_PROTOCOL.md` — 12‑gate path to a publishable proof (math + verification + peer review).
- `VALORLOOP_RESEARCH_PLAN.md` — actionable loop for experiments, conjectures, and formalization.
- `VALORLEGAL_COMMS_PLAYBOOK.md` — safe press, IP, arXiv/journal strategy, and legal guardrails.
- `TEMPLATES/sample_claim_statement.md` — drop‑in text for README/press.
- `TEMPLATES/preprint_cover_letter.md` — arXiv/journal submission cover letter.
- `TEMPLATES/statement_of_scope.md` — “what we prove / what we don’t” insert.
- `TOOLS/ed25519_sign.py` — keygen, sign, verify (no network, local only).
- `TOOLS/sign_manifest.py` — sign SHA‑256 manifest for any directory.
- `TOOLS/build_manifest.py` — make `MANIFEST_SHA256.txt` and JSON map.
- `NOTES/terminology_note.md` — **regularity** vs **regulatory** (don’t mix).

## Quickstart
```bash
python3 -m venv .venv && source .venv/bin/activate
# Build manifest for your results directory (e.g., NS_Engineer_Modular_Verifier_v1)
python TOOLS/build_manifest.py --root ../NS_Engineer_Modular_Verifier_v1 --out artifacts

# Generate a signing keypair (private key stays on your machine)
python TOOLS/ed25519_sign.py keygen --out mykeys
# Sign the manifest
python TOOLS/sign_manifest.py --keys mykeys --manifest artifacts/MANIFEST_SHA256.txt --out artifacts

# Verify signature (on any machine with the public key)
python TOOLS/ed25519_sign.py verify --pub mykeys/public.key     --file artifacts/MANIFEST_SHA256.txt --sig artifacts/MANIFEST_SHA256.txt.sig
```

## Status line you can use today
> “We provide **reproducible verification** of the projection/pressure–Poisson step (with CPU/GPU numerics, interval checks, and cryptographic attestation). We do **not** claim a solution to the Clay problem. Our research path and artifacts are packaged for open verification.”
