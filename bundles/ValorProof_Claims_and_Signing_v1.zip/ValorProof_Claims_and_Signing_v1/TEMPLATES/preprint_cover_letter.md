# Preprint Cover Letter (template)

Dear Editors,

Please consider our manuscript, “Verified Projection/Poisson Equivalence and Reproducible Attestations for Incompressible Flow.” The work provides rigorous derivations and reproducible, hash‑attested numerics for widely used projection methods. It does not claim a proof of 3D global regularity.

We believe the manuscript will be of interest to readers working on numerical analysis and PDE verification. All code and manifests are attached; signatures were produced with Ed25519.

Sincerely,
[Authors]
