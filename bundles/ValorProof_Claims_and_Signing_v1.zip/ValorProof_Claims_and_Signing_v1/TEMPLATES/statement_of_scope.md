# Statement of Scope

**What this work proves:** Projection/Leray step ↔ pressure–Poisson solve on periodic grids, with derivations and reproducible numerics; energy notes for a semi‑discrete scheme.

**What this work does not claim:** A solution to the Clay Millennium Problem on 3D Navier–Stokes global regularity.
