# Sample Claim Statement (drop-in)

We publish a **verification kit** for the projection/pressure–Poisson step used in many incompressible Navier–Stokes solvers. The kit includes proofs of equivalence in the periodic setting, energy‑stability notes, CPU/GPU demos driving post‑projection divergence to machine‑epsilon, and cryptographically signed artifacts for third‑party audit.

**We do not claim** a proof of **3D global regularity**. Our research continues, and all artifacts are provided for open verification.
