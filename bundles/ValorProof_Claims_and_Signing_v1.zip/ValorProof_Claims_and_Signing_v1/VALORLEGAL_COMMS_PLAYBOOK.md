# VALORLEGAL_COMMS_PLAYBOOK — Safe Comms, IP, and PR

## What to publish now
- Proofs of *projection/Poisson equivalence*; energy notes; reproducible CPU/GPU demos; interval checks; attestation manifests.
- Clear **CLAIMS.md** stating scope; **STATEMENT_OF_SCOPE** in every repo.

## IP & Priorities
- Timestamp preprints and code (hash + Ed25519 signatures).
- If a new inequality/lemma is discovered, consider defensive publication vs. provisional patent (if software/process claims apply).

## Press/External
- Use the **Sample Claim Statement** in TEMPLATES.
- Avoid “we solved Navier–Stokes” headlines. Lead with “independently verifiable components + open research plan.”

## Risk
- Overclaiming invites reputational, legal, and academic risk. This playbook minimizes that by enforcing truthful language and artifact attestation.
