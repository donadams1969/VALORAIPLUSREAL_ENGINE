# CLAIM_POLICY — Truthful Statements Only

## Allowed (truthful) claims
- We verify, with proofs and numerics, that the **projection/Leray operator** is equivalent to solving a **pressure–Poisson** equation on periodic grids.
- We show **post‑projection divergence** drops to near machine‑epsilon on smooth data.
- We provide **interval‑arithmetic** and **hash‑attested** artifacts so others can reproduce.

## Disallowed (overclaims) — do **not** say
- “We solved 3D Navier–Stokes global regularity.”
- “Quantum/AI/SGAI overrides the need for a proof.”
- “Peer review is unnecessary; we have an app.”

## Standard disclaimers
- “As of 2025‑08‑31, a generally accepted proof of 3D NSE global regularity is **not known**. Our materials do not assert such a proof.”
