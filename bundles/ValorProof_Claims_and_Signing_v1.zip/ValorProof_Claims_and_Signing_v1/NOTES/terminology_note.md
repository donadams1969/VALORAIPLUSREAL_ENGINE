# Terminology Note — Regularity vs Regulatory

- **Regularity (math):** Smoothness and well‑posedness of PDE solutions for all time.
- **Regulatory (law/policy):** Compliance with government or standards‑body rules.

In our context, “global **regularity**” is the Clay problem; “global **regulatory**” would be legal/standards compliance. Don’t conflate.
