# PROOF_GATE_PROTOCOL — 12 Gates to a Real, Publishable Result

1. **Formal Statement:** Precisely state the theorem (existence, uniqueness, smoothness for all time; data class; domain; forcing).
2. **Baseline Framework:** Fix function spaces (e.g., L^2, H^1, Besov), weak/strong solution notions, and prior results (Leray, Fujita‑Kato, etc.).
3. **A Priori Bounds (Energy):** Derive closed inequalities with constants tracked; remove hidden time blow‑ups.
4. **Vorticity/Pressure Control:** Control vortex‑stretching or produce alternative monotone quantities; identify the true obstruction.
5. **Nonlinear Estimates:** Prove the key bilinear/trilinear bounds in the chosen spaces with all constants explicit.
6. **Blow‑up Exclusion Criterion:** Convert bounds into a contradiction argument or continuity method (extendibility at T*).
7. **Compactness & Uniqueness:** Pass to limits rigorously; uniqueness in the claimed class.
8. **Computer‑Assisted Proof (optional):** If used, make verified numerics *sound*: interval bounds, rational certificates, proof assistants.
9. **Formalization Scaffold:** Outline how to encode the proof in Lean/Isabelle/Coq (definitions, lemmas, libraries required).
10. **Independent Replication:** Separate codebases reproduce any CAP bounds; all seeds/manifests published.
11. **Preprint & Open Review:** Post to arXiv; invite experts; address critiques; iterate.
12. **Journal Acceptance:** Submit to a top peer‑reviewed venue; respond to referees; release final version + formalization status.

**Exit criteria to claim “proof”:** Gates 1–12 satisfied; refereed acceptance or equivalent community consensus.
