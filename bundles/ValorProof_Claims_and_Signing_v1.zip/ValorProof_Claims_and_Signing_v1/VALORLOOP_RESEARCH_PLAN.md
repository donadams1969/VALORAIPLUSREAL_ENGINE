# VALORLOOP_RESEARCH_PLAN — Actionable Loop

**Loop phases: Observe → Conjecture → Prove/Disprove → Verify → Publish → Iterate**

- **Observe:** Run controlled NSE experiments (2D global regularity, 3D small data, decaying turbulence) and extract invariants/heuristics.
- **Conjecture:** Pose bounded, testable lemmas (e.g., new anisotropic inequalities; conditional regularity under structure).
- **Prove/Disprove:** Attack lemmas analytically. If numerics suggest a bound, formalize it or show the barrier explicitly.
- **Verify:** Use interval arithmetic / rational certificates to produce *sound* constants where feasible.
- **Publish:** ArXiv preprints, reproducible code, manifests signed with Ed25519; invite critique.
- **Iterate:** Update conjectures, fix gaps, tighten constants. Track everything in CHANGELOG + MANIFEST.
