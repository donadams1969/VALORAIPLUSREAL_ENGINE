#!/usr/bin/env python3
import os, time, json, requests
from kubernetes import client, config

GATEWAY_URL = os.getenv("GATEWAY_URL","http://gateway")
CM_NAME = os.getenv("CM_NAME","valor-policy")
NAMESPACE = os.getenv("NAMESPACE","default")
INTERVAL = int(os.getenv("INTERVAL","60"))

def get_risk():
    try:
        r = requests.post(f"{GATEWAY_URL}/admin/policy/autotune", json={"context":"finance","actors":["market","new_token"]}, timeout=10)
        r.raise_for_status()
        return r.json().get("hints",{}).get("risk_score",50), r.json().get("hints",{}).get("recommended_allowlist_only",False)
    except Exception:
        return 50, False

def patch_configmap(allowlist: bool):
    config.load_incluster_config()
    v1 = client.CoreV1Api()
    cm = v1.read_namespaced_config_map(CM_NAME, NAMESPACE)
    data = cm.data or {}
    desired = "1" if allowlist else "0"
    if data.get("ALLOWLIST_ONLY","") != desired:
        data["ALLOWLIST_ONLY"] = desired
        cm.data = data
        v1.patch_namespaced_config_map(CM_NAME, NAMESPACE, cm)
        print(f"[policy-supervisor] ALLOWLIST_ONLY -> {desired}")
    else:
        print(f"[policy-supervisor] no change (ALLOWLIST_ONLY={desired})")

def main():
    while True:
        score, recommend = get_risk()
        # Simple threshold: >=60 => enable allowlist-only
        patch_configmap(recommend or score >= 60)
        time.sleep(INTERVAL)

if __name__ == "__main__":
    main()
