from fastapi import FastAPI, Request
from pydantic import BaseModel
import os, httpx
from packages.security.token_guard_advanced import guard as token_guard_advanced

ALLOWLIST_ONLY = os.getenv("ALLOWLIST_ONLY","1") == "1"
PSYCH_URL = os.getenv("PSYCH_URL","http://psych:8000")

app = FastAPI(title="VALOR Gateway v2", version="2.0.0")

class SwapRequest(BaseModel):
    symbol: str
    amount: float
    address: str | None = None

@app.get("/health")
def health():
    return {"ok": True, "allowlist_only": ALLOWLIST_ONLY}

@app.post("/swap")
def swap(req: SwapRequest):
    token_guard_advanced(req.symbol, req.address, allowlist_only=ALLOWLIST_ONLY)
    return {"status":"accepted","symbol":req.symbol,"amount":req.amount,"guard":"ok"}

@app.post("/admin/policy/autotune")
async def autotune(request: Request):
    """ValorPsych+-driven cognitive tuner."""
    body = await request.json()
    context = body.get("context","general")
    actors = body.get("actors",["unknown"])
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.post(f"{PSYCH_URL}/v1/psych/assess", json={"context":context,"actors":actors})
            score = r.json()["result"]["risk_score"]
    except Exception:
        score = 50
    hints = {"recommended_allowlist_only": score >= 60, "risk_score": score}
    return {"ok": True, "hints": hints}
