from fastapi import FastAPI
from pydantic import BaseModel
app=FastAPI()
class S(BaseModel): context:str; actors:list[str]=[]
@app.post('/v1/psych/assess')
def a(s:S): return {'result':{'risk_score': 70 if 'finance' in s.context else 40}}
