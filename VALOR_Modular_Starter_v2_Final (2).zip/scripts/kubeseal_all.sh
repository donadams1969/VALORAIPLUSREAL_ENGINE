#!/usr/bin/env bash
set -euo pipefail
NAMESPACE="${1:-default}"
# Requires: kubeseal and the Sealed Secrets controller installed in the cluster.
for f in k8s/sealed-secrets/templates/*.yaml; do
  base=$(basename "$f" .yaml)
  kubeseal --format yaml --namespace "$NAMESPACE" < "$f" > "k8s/sealed-secrets/${base}.sealed.yaml"
  echo "sealed: k8s/sealed-secrets/${base}.sealed.yaml"
done
