#!/usr/bin/env python3
import json, sys, pathlib
def load(p): return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
if __name__ == "__main__":
    if len(sys.argv)<4: print("usage: quantum_policy_checker.py TOKENLIST IMPOSTERS POLICY"); sys.exit(2)
    tokenlist, imposters, policy = load(sys.argv[1]), load(sys.argv[2]), load(sys.argv[3])
    errors=[]
    tl_syms=[t["symbol"].upper() for t in tokenlist.get("tokens",[]) if t.get("symbol")]
    im_syms=set()
    for it in imposters.get("items",[]):
        if it.get("name"): im_syms.add(it["name"].upper())
        for a in (it.get("aliases") or []): im_syms.add(a.upper())
    clash=set(tl_syms) & im_syms
    if clash: errors.append(f"Collision: {sorted(list(clash))}")
    if len(set(tl_syms))!=len(tl_syms): errors.append("Duplicate symbols in TOKENLIST")
    seen=set()
    for t in tokenlist.get("tokens",[]):
        addr=t.get("address"); chain=t.get("chainId")
        if addr and chain is not None:
            k=(chain,addr.lower())
            if k in seen: errors.append(f"Duplicate (chain,address): {k}")
            seen.add(k)
    if errors:
        print("POLICY CHECK FAILED"); [print("-",e) for e in errors]; sys.exit(1)
    print("POLICY CHECK OK")
