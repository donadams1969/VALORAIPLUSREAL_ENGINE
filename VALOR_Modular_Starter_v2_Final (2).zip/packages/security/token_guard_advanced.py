#!/usr/bin/env python3
import os, re, json, time, pathlib
try:
    import sha3  # keccak
    HAVE_SHA3 = True
except Exception:
    HAVE_SHA3 = False

DEFAULT_TOKENLIST = pathlib.Path(os.getenv("TOKENLIST_PATH","TOKENLIST.json"))
DEFAULT_IMPOSTERS = pathlib.Path(os.getenv("IMPOSTERS_PATH","IMPOSTERS.json"))
_RATE_LIMIT = {}
RATE_MAX = int(os.getenv("RATE_MAX","60"))
RATE_WINDOW = int(os.getenv("RATE_WINDOW","60"))

def _load_json(p):
    P = pathlib.Path(p)
    if P.exists():
        return json.loads(P.read_text(encoding="utf-8"))
    return {"tokens": []}

def levenshtein(a,b):
    a=(a or '').upper(); b=(b or '').upper()
    if a==b: return 0
    m,n=len(a),len(b)
    if m==0: return n
    if n==0: return m
    dp=list(range(n+1))
    for i in range(1,m+1):
        prev,dp[0]=dp[0],i
        for j in range(1,n+1):
            cur=prev if a[i-1]==b[j-1] else min(prev,dp[j],dp[j-1])+1
            prev,dp[j]=dp[j],cur
    return dp[n]

def rate_limit(symbol):
    k=(symbol or '').upper() or 'anon'
    now=int(time.time())
    count,start=_RATE_LIMIT.get(k,(0,now))
    if now-start>=RATE_WINDOW:
        _RATE_LIMIT[k]=(1,now); return
    count+=1; _RATE_LIMIT[k]=(count,start)
    if count>RATE_MAX: raise ValueError(f"rate limited: {k} {count}/{RATE_MAX}")

def is_eip55(address):
    if not re.fullmatch(r"0x[a-fA-F0-9]{40}", address or ""):
        return False
    if not HAVE_SHA3: return True
    raw=address[2:]
    h=sha3.keccak_256(raw.lower().encode()).hexdigest()
    for i,ch in enumerate(raw):
        if ch.isalpha():
            v=int(h[i],16)
            if (v>=8 and ch!=ch.upper()) or (v<8 and ch!=ch.lower()):
                return False
    return True

def similarity_block(symbol, imposters_json):
    sym=(symbol or '').upper()
    for item in imposters_json.get("items",[]):
        for cand in [item.get("name","")] + (item.get("aliases") or []):
            if not cand: continue
            c=cand.upper()
            if levenshtein(sym,c)<=1: return True
    return False

def guard(symbol, address=None, allowlist_only=False):
    rate_limit(symbol)
    tl=_load_json(DEFAULT_TOKENLIST); im=_load_json(DEFAULT_IMPOSTERS)
    allowed={t.get("symbol","").upper(): t for t in tl.get("tokens",[])}
    imp=set()
    for item in im.get("items",[]):
        name=(item.get("name","") or "").upper()
        if name: imp.add(name)
        for a in (item.get("aliases") or []): imp.add((a or "").upper())
    sym=(symbol or '').upper().strip()
    if sym in imp or similarity_block(sym, im):
        raise ValueError(f"Blocked imposter/look-alike: {sym}")
    if allowlist_only and sym not in allowed:
        raise ValueError(f"Unknown token not in allowlist: {sym}")
    if address:
        if not is_eip55(address): raise ValueError(f"EIP-55 fail: {address}")
        listed=allowed.get(sym,{}).get("address")
        if listed and listed.lower()!=address.lower():
            raise ValueError(f"Address mismatch for {sym}: expected {listed}, got {address}")
    return True
