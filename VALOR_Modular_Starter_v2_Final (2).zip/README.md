# VALOR Modular Starter v2 — Final (SecFusion + Supervisor + Sealed-Secrets)
**Generated (UTC):** 2025-09-01T14:24:22Z

- Quantum Token-Guard++ (advanced) + strict policy
- Prod K8s overlay with TLS/HPA/WAF
- **Policy Supervisor** (Deployment + RBAC) auto-flips ALLOWLIST via ConfigMap with Psych+ risk
- **Sealed-Secrets templates** for TLS + Cosign OIDC restrictions (`scripts/kubeseal_all.sh`)
- CI (security-suite) & keyless secure release (cosign + OpenTimestamps)

## Apply
1) Populate `TOKENLIST.json` (checksummed addresses) and keep `IMPOSTERS.json` current.
2) `kubectl apply -k k8s/overlays/prod` (edit host/TLS first).
3) Build & push the policy supervisor image, then update `image:` in `k8s/overlays/prod/policy-supervisor.yaml`.
4) Run `scripts/kubeseal_all.sh` after placing real secrets in `k8s/sealed-secrets/templates/`.

## Notes
- The sealed-secrets files are **templates**; run `kubeseal` against your cluster to produce encrypted manifests.
- Cosign is configured keyless (OIDC). Restrict repos/subjects using the `cosign-oidc-secret` template and your verification jobs.
