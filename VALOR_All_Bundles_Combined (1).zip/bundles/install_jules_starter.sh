#!/usr/bin/env bash
# recreated installer
set -euo pipefail
echo 'Install Jules starter (recreated)'
