Write-Host 'Install Jules starter (recreated)'
